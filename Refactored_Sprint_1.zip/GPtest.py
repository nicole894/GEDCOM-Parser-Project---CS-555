import unittest
from prettytable import PrettyTable
import GDriver as D

class TestUS(unittest.TestCase):
    __ALL__=["US01","US02","US03","US21","US22","US35","US36","US42"]
    __INFO__=["US35", "US36"]
    p=D.main("GEDCOM_File_goodOne.ged")

    def testAll(self):
        for _test in self.__ALL__:
            with self.subTest(test=_test):
                x = None
                logs = [i for i in self.p.log if i[0]==_test]
                count=len(logs)
                if _test in self.__INFO__:
                    if count==1:
                        print(f"{_test} Output: \n{logs[0][2][0]}")
                    self.assertEqual(count, 1,f"{_test}: This test should always generate an INFO.")
                else:
                    if count:
                        x = PrettyTable(["Test","Case","Spec"])
                        for i in self.p.log:
                            if i[0]==_test:
                                x.add_row(i)
                    self.assertEqual(count, 0, f"{_test}: There is {count} error found in GEDCOM file:\n{x}")

if __name__ == '__main__':
    unittest.main()
