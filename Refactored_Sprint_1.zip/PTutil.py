#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date     : 2019-10-11 17:28:23
# @Author   : Mingyu Yao (myao4@stevens.edu)
# @Version  : 0.2.3
# @Description  : Pretty Table Utility With 'NA'
from prettytable import PrettyTable
import time

api_version=203

today = time.strftime("%Y %m %d").split(' ')
month=['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
log_level=["US35","US36"]
log_func={
    ("US01","B_NA"): lambda x: f"US01: INDI: {x[0]}: Birth Date is not known",
    ("US01","BIRT"): lambda x: f"US01: INDI: {x[0]}: Birth Date {x[1]} is before today's date",
    ("US01","DEAT"): lambda x: f"US01: INDI: {x[0]}: Death Date {x[1]} is before today's date",
    ("US01","M_NA"): lambda x: f"US01: FAM: {x[0]}: Marriage Date is not known",
    ("US01","MARR"): lambda x: f"US01: FAM: {x[0]}: Marriage Date {x[1]} is before today's date",
    ("US01","DIV"): lambda x: f"US01: FAM: {x[0]}: Divorce Date {x[1]} is before today's date.",

    ("US02","M_NA"): lambda x: f"US02: FAM: {x[0]}: Marriage Date is not known",
    ("US02","H_NA"): lambda x: f"US02: FAM: {x[0]}: Husband's Birth Date is not known",
    ("US02","HUSB"): lambda x: f"US02: FAM: {x[0]}: Husband's ({x[1]}) Birth Date {x[2]} is after Marriage Date {x[3]}",
    ("US02","W_NA"): lambda x: f"US02: FAM: {x[0]}: Wife's Birth Date is not known",
    ("US02","WIFE"): lambda x: f"US02: FAM: {x[0]}: Wife's ({x[1]}) Birth Date {x[2]} is after Marriage Date {x[3]}",

    ("US03","INDI"): lambda x: f"US01: INDI: {x[0]}: Death Date {x[1]} is before Birth Date {x[2]}",

    ("US21","HUSB"): lambda x: f"US21: FAM: {x[0]}: Husband ({x[1]}) has incorrect gender",
    ("US21","WIFE"): lambda x: f"US21: FAM: {x[0]}: Wife ({x[1]}) has incorrect gender",

    ("US22","FAM"): lambda x: f"US22: FAM: {x[0]}: Family already exists",
    ("US22","INDI"): lambda x: f"US22: INDI: {x[0]}: Individual already exists",

    ("US35","BIRT"): lambda x: f"INFO: US35: INDI: List all birthdays in the last 30 days \n {x[0]}",
    ("US36","DEAT"): lambda x: f"INFO: US36: INDI: List all deaths in the last 30 days \n {x[0]}",

    ("US42","BIRT"): lambda x: f"US42: INDI: {x[0]}: Illegitimate date for Birth Date {x[1]}",
    ("US42","DEAT"): lambda x: f"US42: INDI: {x[0]}: Illegitimate date for Death Date {x[1]}",
    ("US42","MARR"): lambda x: f"US42: FAM: {x[0]}: Illegitimate date for Marraige Date {x[1]}",
    ("US42","DIV"): lambda x: f"US42: FAM: {x[0]}: Illegitimate date for Divorce Date {x[1]}"
    }

def date_format(date_list):
    yyyy=date_list[2]
    mm=('%02d' % (month.index(date_list[1])+1))
    dd= '%02d' % int(date_list[0])
    return (yyyy, mm, dd)

def age_carry(new,old):
    if(new[1]<old[1]):
        return 1
    elif(new[1]==old[1] and new[2]<old[2]):
        return 1
    else:
        return 0

def print_indi(indi_dict):
    x = PrettyTable(["ID","Name","Gender","Birthday","Age","Alive","Death","Child","Spouse"])
    for k,v in indi_dict.items():
        uid=k
        name=v.get('NAME')
        sex=v.get('SEX', 'NA')
        DOB=v.get('BIRT', 'NA')
        born = (DOB!='NA')
        if born:
            DOB=date_format(DOB.split(' '))
        DOD=v.get('DEAT','NA')
        alive=(DOD=='NA')
        if not alive:
            DOD = date_format(DOD.split(' '))
        if not born:
            age = 'NA'
        elif alive:
            age = int(today[0]) - int(DOB[0]) - age_carry(today,DOB)
        else:
            age = int(DOD[0]) - int(DOB[0]) - age_carry(DOD,DOB)
        child=v.get('FAMC','NA')
        spouse=v.get('FAMS', 'NA')
        x.add_row([uid,name,sex,born and '-'.join(DOB) or 'NA', age, born and alive, alive and 'NA' or '-'.join(DOD), child, spouse])
    print(x)

def print_fam(fam_dict, indi_dict):
    def get_name(indi_dict,nid):
        return indi_dict[nid].get('NAME')
    
    x=PrettyTable(["ID","Married","Divorced","Husband ID","Husband Name","Wife ID","Wife Name","Children"])
    for k,v in fam_dict.items():
        uid=k
        mar= v.get('MARR', 'NA')
        if (mar!='NA'):
            mar = date_format(mar.split(' '))
        div=v.get('DIV', 'NA')
        if div!='NA':
            div=date_format(div.split(' '))
        hid=v.get('HUSB')
        hname=get_name(indi_dict,hid)
        wid=v.get('WIFE')
        wname=get_name(indi_dict,wid)
        children= v.get('CHIL','NA')
        x.add_row([uid, (mar=='NA') and 'NA' or '-'.join(mar), (div=='NA') and 'NA' or '-'.join(div),hid,hname,wid,wname,children])       
    print(x)
    
def print_log(log_dict):
    for i in log_dict:
        if i[0] in log_level:
            print(log_func[i[0],i[1]](i[2]))
        else:
            print("ERROR: "+ log_func[i[0],i[1]](i[2]))